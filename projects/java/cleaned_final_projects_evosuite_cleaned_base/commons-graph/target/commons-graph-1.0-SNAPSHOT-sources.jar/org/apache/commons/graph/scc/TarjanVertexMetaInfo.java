package org.apache.commons.graph.scc;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

final class TarjanVertexMetaInfo {

    private static final int UNDEFINED = -1;

    private int index = UNDEFINED;

    private int lowLink = UNDEFINED;

    public int getIndex() {
        return index;
    }

    public int getLowLink() {
        return lowLink;
    }

    public boolean hasUndefinedIndex() {
        return UNDEFINED == index;
    }

    public void setIndex(int index_param) {
        this.index = index_param;
    }

    public void setLowLink(int lowLink_param) {
        this.lowLink = lowLink_param;
    }
}
