
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import java.io.File;
import java.io.FileInputStream;
import java.lang.Throwable;
import java.util.Date;
import org.junit.Test;
import static org.junit.Assert.*;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PatternOptionBuilder;

public class PatternOptionBuilder_ESTest  {

  @Test
  public void test00()  throws Throwable  {
      // Undeclared exception!
      try { 
        PatternOptionBuilder.parsePattern((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
}
  }

  @Test
  public void test01()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode(':');
      assertTrue(boolean0);
  }

  @Test
  public void test02()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('<');
      assertTrue(boolean0);
  }

  @Test
  public void test03()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('!');
      assertTrue(boolean0);
  }

  @Test
  public void test04()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('#');
      assertTrue(boolean0);
  }

  @Test
  public void test05()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('/');
      assertTrue(boolean0);
  }

  @Test
  public void test06()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('@');
      assertTrue(boolean0);
  }

  @Test
  public void test07()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('\'');
      assertFalse(boolean0);
  }

  @Test
  public void test08()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('+');
      assertTrue(boolean0);
  }

  @Test
  public void test09()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('*');
      assertTrue(boolean0);
  }

  @Test
  public void test10()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('@');
      assertEquals("class java.lang.Object", object0.toString());
      assertNotNull(object0);
  }

  @Test
  public void test11()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass(':');
      assertEquals("class java.lang.String", object0.toString());
      assertNotNull(object0);
  }

  @Test
  public void test12()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('+');
      assertEquals("class java.lang.Class", object0.toString());
      assertNotNull(object0);
  }

  @Test
  public void test13()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('<');
      assertNotNull(object0);
      assertEquals("class java.io.FileInputStream", object0.toString());
  }

  @Test
  public void test14()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('/');
      assertNotNull(object0);
      assertEquals("class java.net.URL", object0.toString());
  }

  @Test
  public void test15()  throws Throwable  {
      Class class0 = (Class)PatternOptionBuilder.getValueClass('*');
      assertTrue(class0.isArray());
      assertNotNull(class0);
  }

  @Test
  public void test16()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('>');
      assertTrue(boolean0);
  }

  @Test
  public void test17()  throws Throwable  {
      Options options0 = PatternOptionBuilder.parsePattern("#uw!oo*cb69#R8xL*b");
      assertNotNull(options0);
  }

  @Test
  public void test18()  throws Throwable  {
      boolean boolean0 = PatternOptionBuilder.isValueCode('%');
      assertTrue(boolean0);
  }

  @Test
  public void test19()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('j');
      assertNull(object0);
  }

  @Test
  public void test20()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('?');
      assertNull(object0);
  }

  @Test
  public void test21()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('>');
      assertEquals("class java.io.File", object0.toString());
      assertNotNull(object0);
  }

  @Test
  public void test22()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('=');
      assertNull(object0);
  }

  @Test
  public void test23()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass(';');
      assertNull(object0);
  }

  @Test
  public void test24()  throws Throwable  {
      Options options0 = PatternOptionBuilder.parsePattern("A CloneNotSupportedException was trown: ");
      assertNotNull(options0);
  }

  @Test
  public void test25()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('9');
      assertNull(object0);
  }

  @Test
  public void test26()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('8');
      assertNull(object0);
  }

  @Test
  public void test27()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('7');
      assertNull(object0);
  }

  @Test
  public void test28()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('6');
      assertNull(object0);
  }

  @Test
  public void test29()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('5');
      assertNull(object0);
  }

  @Test
  public void test30()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('4');
      assertNull(object0);
  }

  @Test
  public void test31()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('3');
      assertNull(object0);
  }

  @Test
  public void test32()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('2');
      assertNull(object0);
  }

  @Test
  public void test33()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('1');
      assertNull(object0);
  }

  @Test
  public void test34()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('0');
      assertNull(object0);
  }

  @Test
  public void test35()  throws Throwable  {
      Options options0 = PatternOptionBuilder.parsePattern("BS_q/_/");
      assertNotNull(options0);
  }

  @Test
  public void test36()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('.');
      assertNull(object0);
  }

  @Test
  public void test37()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('-');
      assertNull(object0);
  }

  @Test
  public void test38()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass(',');
      assertNull(object0);
  }

  @Test
  public void test39()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass(')');
      assertNull(object0);
  }

  @Test
  public void test40()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('(');
      assertNull(object0);
  }

  @Test
  public void test41()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('\'');
      assertNull(object0);
  }

  @Test
  public void test42()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('&');
      assertNull(object0);
  }

  @Test
  public void test43()  throws Throwable  {
      Class class0 = (Class)PatternOptionBuilder.getValueClass('%');
      assertEquals(1025, class0.getModifiers());
      assertNotNull(class0);
  }

  @Test
  public void test44()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('$');
      assertNull(object0);
  }

  @Test
  public void test45()  throws Throwable  {
      // Undeclared exception!
      try { 
        PatternOptionBuilder.parsePattern("O*$c2v;!+Beqc");
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Illegal option name ';'
         //
}
  }

  @Test
  public void test46()  throws Throwable  {
      Object object0 = PatternOptionBuilder.getValueClass('#');
      assertNotNull(object0);
      assertEquals("class java.util.Date", object0.toString());
  }

  @Test
  public void test47()  throws Throwable  {
      PatternOptionBuilder patternOptionBuilder0 = new PatternOptionBuilder();
  }
}
