
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import java.lang.Throwable;
import org.junit.Test;
import static org.junit.Assert.*;
import org.apache.commons.cli.Util;

public class Util_ESTest  {

  @Test
  public void test00()  throws Throwable  {
      // Undeclared exception!
      try { 
        Util.stripLeadingAndTrailingQuotes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
}
  }

  @Test
  public void test01()  throws Throwable  {
      String string0 = Util.stripLeadingHyphens("-!_!R:-vkZHq");
      assertEquals("!_!R:-vkZHq", string0);
  }

  @Test
  public void test02()  throws Throwable  {
      String string0 = Util.stripLeadingHyphens("");
      assertEquals("", string0);
  }

  @Test
  public void test03()  throws Throwable  {
      String string0 = Util.stripLeadingHyphens((String) null);
      assertNull(string0);
  }

  @Test
  public void test04()  throws Throwable  {
      String string0 = Util.stripLeadingHyphens("--");
      assertNotNull(string0);
      assertEquals("", string0);
  }

  @Test
  public void test05()  throws Throwable  {
      String string0 = Util.stripLeadingAndTrailingQuotes("\"--\"");
      assertEquals("--", string0);
  }

  @Test
  public void test06()  throws Throwable  {
      String string0 = Util.stripLeadingAndTrailingQuotes("\"!_!R:-vkZHq");
      assertEquals("\"!_!R:-vkZHq", string0);
  }

  @Test
  public void test07()  throws Throwable  {
      String string0 = Util.stripLeadingAndTrailingQuotes("\"\"--\"");
      assertEquals("\"\"--\"", string0);
  }

  @Test
  public void test08()  throws Throwable  {
      String string0 = Util.stripLeadingAndTrailingQuotes(";ELV?%J2rx*!R");
      assertEquals(";ELV?%J2rx*!R", string0);
  }

  @Test
  public void test09()  throws Throwable  {
      String string0 = Util.stripLeadingAndTrailingQuotes("");
      assertEquals("", string0);
  }

  @Test
  public void test10()  throws Throwable  {
      Util util0 = new Util();
  }
}
